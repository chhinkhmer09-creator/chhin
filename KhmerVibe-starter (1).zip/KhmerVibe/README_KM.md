# KhmerVibe — មគ្គុទ្ទេសក៍ដំឡើងជាភាសាខ្មែរ

KhmerVibe គឺជា starter project សម្រាប់ Web App វីដេអូខ្លីដែលអាចដំឡើងជាបែប PWA លើ Android។ វាមិនមែនជាការចម្លង TikTok ទេ។

## អ្វីដែលមាននៅក្នុងកំណែនេះ
- ចុះឈ្មោះ/ចូលគណនីដោយ Firebase Authentication (អ៊ីមែល/ពាក្យសម្ងាត់)
- វីដេអូ Feed, ស្វែងរក, Upload ទៅ Firebase Storage
- Like, Comment, Follow
- សារផ្ទាល់តាម Firestore (អ្នកត្រូវមាន UID អ្នកទទួល)
- ទំព័រ Profile និងលុបវីដេអូផ្ទាល់ខ្លួន
- ផ្ទាំង Admin ជាមូលដ្ឋាន
- PWA manifest ដើម្បីដំឡើងលើ Android
- Firestore និង Storage Security Rules

## អ្វីដែលមិនទាន់រួចរាល់/ត្រូវបន្ថែមមុនដាក់ប្រើពិត
- Live Streaming មិនទាន់ភ្ជាប់៖ ត្រូវមាន LiveKit/WebRTC provider និង Backend token endpoint។ កុំដាក់ API Secret នៅ frontend។
- Counter Like/Comment ក្នុង UI នេះជាការធ្វើបច្ចុប្បន្នភាពផ្នែក client មិនទាន់ប្រើ Cloud Functions/transaction ដូច្នេះមិនធន់នឹងការចុចព្រមគ្នាច្រើន។ មុនបើកប្រើសាធារណៈ ត្រូវប្ដូរទៅ Cloud Functions ដែលផ្ទៀងផ្ទាត់សិទ្ធិ។
- មិនទាន់មានការត្រួតពិនិត្យមាតិកា, រាយការណ៍/ប្លុកអ្នកប្រើ, rate limits, push notifications, video transcoding ឬ CDN។
- មិនទាន់មានសេវាស្វែងរកអ្នកប្រើតាមឈ្មោះ ឬ inbox UI ពេញលេញ។
- Firebase Web config មិនមែនជាការសម្ងាត់; សុវត្ថិភាពពឹងលើ Rules និងការកំណត់ Firebase Console។
- ត្រូវសាកល្បង Rules ដោយ Firebase Emulator មុនដាក់ប្រើជាសាធារណៈ។

## តម្រូវការ
- Node.js LTS (ណែនាំ Node 20 ឬថ្មីជាងនេះ)
- គណនី Google និង Firebase project
- Google AI Studio អាចប្រើសម្រាប់ជួយកែ/ពង្រីកកូដ ប៉ុន្តែ hosting, database, storage និង auth ត្រូវកំណត់ក្នុង Firebase ដាច់ដោយឡែក។

## ជំហានទី ១ — បង្កើត Firebase Project
1. បើក https://console.firebase.google.com/
2. ចុច Add project ហើយដាក់ឈ្មោះ `KhmerVibe` (ឬឈ្មោះដែលអ្នកចង់បាន)។
3. ចូល Project settings → General → Your apps → Add app → Web។
4. ចម្លង Firebase web config។
5. នៅ Firebase Console បើក Authentication → Sign-in method → Email/Password → Enable។
6. បង្កើត Firestore Database (Production mode)។
7. បើក Storage ហើយបង្កើត bucket។ ប្រសិនបើ Firebase តម្រូវឱ្យបើក billing សូមពិនិត្យតម្លៃ និងតំបន់ដែលគាំទ្រមុន។

## ជំហានទី ២ — ដាក់ Firebase Config
1. Extract ZIP នេះ។
2. ចម្លង `.env.example` ទៅជា `.env.local`។
3. បញ្ចូលតម្លៃ API key, auth domain, project ID, storage bucket, sender ID និង app ID ពី Firebase Console។
4. កុំបញ្ចូល Service Account private key ឬ Gemini secret key ទៅ `.env.local` ដែលចាប់ផ្ដើមដោយ `VITE_` ឬកូដ frontend ឡើយ។

## ជំហានទី ៣ — ដំឡើង និងដំណើរការក្នុងកុំព្យូទ័រ
បើក Terminal នៅក្នុង folder `KhmerVibe` ហើយរត់៖

```bash
npm install
npm run dev
```

Vite នឹងបង្ហាញ local URL (ជាធម្មតា http://localhost:5173)។ បើមានបញ្ហា សូមពិនិត្យ `.env.local` និង Console errors។

## ជំហានទី ៤ — ដាក់ Security Rules
ដំឡើង Firebase CLI៖

```bash
npm install -g firebase-tools
firebase login
firebase use --add
firebase deploy --only firestore:rules,storage
```

ជ្រើស Project ID របស់អ្នក។ សូមអាន `firestore.rules` និង `storage.rules` មុន deploy។ កុំប្រើ `allow read, write: if true` សម្រាប់ទិន្នន័យឯកជន។

## ជំហានទី ៥ — កំណត់ Admin យ៉ាងសុវត្ថិភាព
1. បង្កើតគណនីធម្មតាមួយពី App។
2. ចូល Firebase Console → Firestore → `users` → ឯកសារដែល ID ដូច UID របស់គណនីនោះ។
3. កែ field `role` ពី `user` ទៅ `admin` ដោយម្ចាស់ project ប៉ុណ្ណោះ។
4. កុំបន្ថែមប៊ូតុង frontend ដែលអនុញ្ញាតឱ្យអ្នកប្រើផ្លាស់ប្ដូរខ្លួនទៅជា admin។
5. នៅ production គួរប្រើ Firebase Admin SDK/Custom Claims នៅ server និងត្រួតពិនិត្យសិទ្ធិម្ដងទៀត។

## ជំហានទី ៦ — Build និង Deploy Web
```bash
npm run build
firebase deploy --only hosting
```
បន្ទាប់មក Firebase Hosting នឹងផ្ដល់ HTTPS URL។ PWA អាចដំឡើងពី Chrome Android តាម menu → Install app ឬ Add to Home screen។ PWA មិនដូច native APK ទេ។

## ជំហានទី ៧ — Live Streaming
សម្រាប់ Live ពិតប្រាកដ៖
1. បង្កើត LiveKit Cloud project ឬដាក់ server ផ្ទាល់។
2. បង្កើត backend endpoint (ឧ. Cloud Functions/Cloud Run) ដែលពិនិត្យ Firebase ID token ហើយចេញ LiveKit room token រយៈពេលខ្លី។
3. រក្សា LiveKit API Secret នៅ server secret manager ប៉ុណ្ណោះ។
4. បន្ថែម LiveKit client SDK និង UI សម្រាប់ create/join/leave room, microphone, camera, report/block និង moderation។
5. កំណត់ quota និងការចំណាយរបស់ LiveKit មុនបើកសាធារណៈ។

## ជំហានទី ៨ — ប្រើ Google AI Studio
1. បើក https://aistudio.google.com/
2. បង្កើត project/app ថ្មី (ឬប្រើ Build mode ប្រសិនបើមានក្នុងគណនី)។
3. បើត្រូវ paste កូដ ចូរបញ្ចូលឯកសារពី ZIP ដោយរក្សារចនាសម្ព័ន្ធ folder។
4. អាចស្នើ AI Studio ជួយកែ UI ឬបន្ថែមមុខងារ ប៉ុន្តែសាកល្បង build និង Firebase Rules នៅក្នុង environment របស់អ្នក។
5. កុំបញ្ចូល Firebase Admin private key, LiveKit secret ឬ credential ឯកជនទៅ prompt/chat/frontend។

## សុវត្ថិភាព និងឯកជនភាព
- កំណត់ Firebase App Check និង Authentication domain allowlist។
- ប្រើ rate limit និង Cloud Functions សម្រាប់ likes/comments, validation និងការលុប Storage objects។
- កុំទុក URL/UID ជាភស្តុតាងសិទ្ធិ; ត្រូវពិនិត្យ auth និង ownership នៅ Rules/server។
- បន្ថែម report/block, content moderation, privacy policy, terms, age-appropriate safety និងការឆ្លើយតបចំពោះ copyright complaints មុន public launch។
- កំណត់ budget alerts និងមើលការប្រើប្រាស់ Firebase Storage/egress; វីដេអូអាចបង្កើតការចំណាយច្រើន។
- ធ្វើ backup និងសាកល្បង security rules ជាមួយ Firebase Emulator Suite។

## Troubleshooting
- `Missing or insufficient permissions`: ពិនិត្យ Authentication និង Firestore Rules។
- Upload fail: ពិនិត្យ Storage enabled, bucket និង Storage Rules។
- Feed មិនបង្ហាញ: ត្រូវមាន `createdAt` timestamp និង documents ក្នុង `videos`។
- Android Install មិនបង្ហាញ: ត្រូវ deploy HTTPS ហើយពិនិត្យ manifest/icon។
- មិនអាច Login: បើក Email/Password provider នៅ Firebase Authentication។
