export type Profile = {
  uid: string; username: string; displayName: string; bio?: string;
  avatarUrl?: string; role?: "user" | "admin"; createdAt?: unknown;
};
export type VideoPost = {
  id: string; ownerId: string; ownerName: string; ownerUsername: string;
  caption: string; videoUrl: string; thumbnailUrl?: string;
  createdAt?: unknown; likesCount?: number; commentsCount?: number;
};
export type Comment = { id: string; uid: string; username: string; text: string; createdAt?: unknown };
