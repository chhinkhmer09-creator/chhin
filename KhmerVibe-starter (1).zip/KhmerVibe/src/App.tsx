import { useEffect, useMemo, useState } from "react";
import {
  addDoc, collection, doc, getDoc, getDocs, limit, onSnapshot, orderBy,
  query, serverTimestamp, setDoc, where, deleteDoc
} from "firebase/firestore";
import {
  createUserWithEmailAndPassword, onAuthStateChanged, signInWithEmailAndPassword,
  signOut, updateProfile, type User
} from "firebase/auth";
import { ref, uploadBytesResumable, getDownloadURL } from "firebase/storage";
import { auth, db, storage } from "./firebase";
import type { Comment, Profile, VideoPost } from "./types";
import { Heart, MessageCircle, Plus, House, UserRound, LogOut, Send, Radio, Shield, X, Search } from "lucide-react";

type Tab = "feed" | "upload" | "chat" | "live" | "profile" | "admin";
const kh = (n?: number) => Intl.NumberFormat("km-KH", { notation: n && n >= 1000 ? "compact" : "standard", maximumFractionDigits: 1 }).format(n || 0);

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [tab, setTab] = useState<Tab>("feed");
  const [posts, setPosts] = useState<VideoPost[]>([]);
  const [authMode, setAuthMode] = useState<"login"|"register">("login");
  const [email, setEmail] = useState(""); const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState(""); const [error, setError] = useState("");
  const [caption, setCaption] = useState(""); const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false); const [progress, setProgress] = useState(0);
  const [activePost, setActivePost] = useState(""); const [comments, setComments] = useState<Comment[]>([]);
  const [commentText, setCommentText] = useState(""); const [chatTarget, setChatTarget] = useState("");
  const [chatText, setChatText] = useState(""); const [messages, setMessages] = useState<any[]>([]);
  const [following, setFollowing] = useState<string[]>([]); const [liked, setLiked] = useState<string[]>([]);
  const [search, setSearch] = useState(""); const [notice, setNotice] = useState("");

  useEffect(() => onAuthStateChanged(auth, async u => {
    setUser(u);
    if (!u) { setProfile(null); return; }
    const snap = await getDoc(doc(db, "users", u.uid));
    if (snap.exists()) setProfile(snap.data() as Profile);
    else {
      const p: Profile = { uid:u.uid, username:(u.email?.split("@")[0] || "user").replace(/[^a-zA-Z0-9_]/g,"").slice(0,20), displayName:u.displayName || "អ្នកប្រើថ្មី", role:"user", createdAt:serverTimestamp() };
      await setDoc(doc(db,"users",u.uid),p); setProfile(p);
    }
  }), []);

  useEffect(() => {
    const q = query(collection(db,"videos"), orderBy("createdAt","desc"), limit(80));
    return onSnapshot(q, snap => setPosts(snap.docs.map(d=>({id:d.id,...d.data()} as VideoPost))), e => setError(e.message));
  }, []);

  useEffect(() => {
    if (!user) return;
    const unsub1 = onSnapshot(collection(db,"users",user.uid,"likes"), s => setLiked(s.docs.map(d=>d.id)));
    const unsub2 = onSnapshot(collection(db,"users",user.uid,"following"), s => setFollowing(s.docs.map(d=>d.id)));
    return () => { unsub1(); unsub2(); };
  }, [user]);

  useEffect(() => {
    if (!activePost) { setComments([]); return; }
    return onSnapshot(query(collection(db,"videos",activePost,"comments"),orderBy("createdAt","asc"),limit(100)),
      s=>setComments(s.docs.map(d=>({id:d.id,...d.data()} as Comment))));
  }, [activePost]);

  useEffect(() => {
    if (!user || !chatTarget) { setMessages([]); return; }
    const chatId = [user.uid,chatTarget].sort().join("_");
    return onSnapshot(query(collection(db,"chats",chatId,"messages"),orderBy("createdAt","asc"),limit(100)),
      s=>setMessages(s.docs.map(d=>({id:d.id,...d.data()}))));
  }, [user,chatTarget]);

  const visiblePosts = useMemo(() => posts.filter(p =>
    !search || (p.caption+" "+p.ownerName+" "+p.ownerUsername).toLowerCase().includes(search.toLowerCase())
  ), [posts,search]);

  async function submitAuth(e: React.FormEvent) {
    e.preventDefault(); setError("");
    try {
      if (authMode === "register") {
        const cred = await createUserWithEmailAndPassword(auth,email,password);
        await updateProfile(cred.user,{displayName:displayName || "អ្នកប្រើថ្មី"});
        const username = (email.split("@")[0] || "user").replace(/[^a-zA-Z0-9_]/g,"").slice(0,20);
        const p: Profile = {uid:cred.user.uid,username,displayName:displayName || "អ្នកប្រើថ្មី",role:"user",createdAt:serverTimestamp()};
        await setDoc(doc(db,"users",cred.user.uid),p); setProfile(p);
      } else await signInWithEmailAndPassword(auth,email,password);
    } catch (e:any) { setError(friendlyError(e.code) || e.message); }
  }

  async function uploadVideo(e: React.FormEvent) {
    e.preventDefault(); if (!user || !profile || !file) return;
    if (!file.type.startsWith("video/")) { setError("សូមជ្រើសឯកសារវីដេអូ។"); return; }
    if (file.size > 200 * 1024 * 1024) { setError("វីដេអូធំពេក។ សាកល្បងឯកសារតិចជាង ២០០ MB។"); return; }
    setUploading(true); setError("");
    try {
      const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g,"_");
      const storageRef = ref(storage,`videos/${user.uid}/${Date.now()}_${safeName}`);
      const task = uploadBytesResumable(storageRef,file,{contentType:file.type});
      await new Promise<void>((resolve,reject)=>task.on("state_changed",
        s=>setProgress(Math.round(s.bytesTransferred/s.totalBytes*100)),reject,()=>resolve()));
      const videoUrl = await getDownloadURL(storageRef);
      await addDoc(collection(db,"videos"),{
        ownerId:user.uid, ownerName:profile.displayName, ownerUsername:profile.username,
        caption:caption.trim().slice(0,300), videoUrl, createdAt:serverTimestamp(), likesCount:0, commentsCount:0
      });
      setCaption(""); setFile(null); setProgress(0); setNotice("បានបង្ហោះវីដេអូដោយជោគជ័យ!"); setTab("feed");
    } catch(e:any) { setError("បង្ហោះមិនបាន៖ "+(e.message || "សូមពិនិត្យការកំណត់ Firebase")); }
    finally { setUploading(false); }
  }

  async function toggleLike(p: VideoPost) {
    if (!user) return setNotice("សូមចូលគណនីជាមុនសិន។");
    const likeRef = doc(db,"users",user.uid,"likes",p.id);
    const exists = liked.includes(p.id);
    try {
      if (exists) await deleteDoc(likeRef); else await setDoc(likeRef,{videoId:p.id,createdAt:serverTimestamp()});
    } catch(e:any) { setError(e.message); }
  }

  async function addComment(e: React.FormEvent) {
    e.preventDefault(); if (!user || !profile || !activePost || !commentText.trim()) return;
    try {
      await addDoc(collection(db,"videos",activePost,"comments"),{uid:user.uid,username:profile.username,text:commentText.trim().slice(0,500),createdAt:serverTimestamp()});
      setCommentText("");
    } catch(e:any) { setError(e.message); }
  }

  async function toggleFollow(ownerId: string) {
    if (!user || ownerId===user.uid) return;
    const r = doc(db,"users",user.uid,"following",ownerId);
    try { if(following.includes(ownerId)) await deleteDoc(r); else await setDoc(r,{uid:ownerId,createdAt:serverTimestamp()}); }
    catch(e:any) { setError(e.message); }
  }

  async function sendMessage(e: React.FormEvent) {
    e.preventDefault(); if(!user || !profile || !chatTarget || !chatText.trim()) return;
    const chatId=[user.uid,chatTarget].sort().join("_");
    try {
      await addDoc(collection(db,"chats",chatId,"messages"),{senderId:user.uid,senderName:profile.displayName,text:chatText.trim().slice(0,1000),createdAt:serverTimestamp()});
      await setDoc(doc(db,"chats",chatId),{members:[user.uid,chatTarget],updatedAt:serverTimestamp(),lastMessage:chatText.trim().slice(0,100)});
      setChatText("");
    } catch(e:any) { setError("ផ្ញើសារមិនបាន៖ "+e.message); }
  }

  if (!user) return <main className="authPage"><div className="brandMark">KV</div><h1>KhmerVibe</h1><p className="muted">វីដេអូខ្លី • សហគមន៍ខ្មែរ</p>
    <form className="authCard" onSubmit={submitAuth}><h2>{authMode==="login"?"សូមស្វាគមន៍ត្រឡប់មកវិញ":"បង្កើតគណនីថ្មី"}</h2>
      {authMode==="register" && <label>ឈ្មោះបង្ហាញ<input required value={displayName} onChange={e=>setDisplayName(e.target.value)} maxLength={40} placeholder="ឈ្មោះរបស់អ្នក"/></label>}
      <label>អ៊ីមែល<input type="email" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" autoComplete="email"/></label>
      <label>ពាក្យសម្ងាត់<input type="password" required minLength={6} value={password} onChange={e=>setPassword(e.target.value)} placeholder="យ៉ាងតិច ៦ តួ" autoComplete={authMode==="login"?"current-password":"new-password"}/></label>
      {error&&<p className="error">{error}</p>}<button className="primary full">{authMode==="login"?"ចូលគណនី":"ចុះឈ្មោះ"}</button>
      <p className="switchAuth">{authMode==="login"?"មិនទាន់មានគណនី?":"មានគណនីរួចហើយ?"} <button type="button" className="link" onClick={()=>setAuthMode(authMode==="login"?"register":"login")}>{authMode==="login"?"ចុះឈ្មោះ":"ចូលគណនី"}</button></p>
    </form><p className="tiny muted">ដោយបន្ត អ្នកយល់ព្រមប្រើប្រាស់សេវាកម្មដោយមានទំនួលខុសត្រូវ។</p></main>;

  return <div className="appShell">
    <header className="topbar"><div className="brand"><span className="brandMark small">KV</span><b>KhmerVibe</b></div>
      <div className="searchBox"><Search size={17}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="ស្វែងរកវីដេអូ..."/></div>
      <div className="topUser"><span>{profile?.displayName || user.email}</span><button className="iconButton" title="ចេញពីគណនី" onClick={()=>signOut(auth)}><LogOut size={18}/></button></div>
    </header>
    <aside className="sidebar">
      <NavButton icon={<House/>} label="សម្រាប់អ្នក" active={tab==="feed"} onClick={()=>setTab("feed")}/>
      <NavButton icon={<Plus/>} label="បង្ហោះវីដេអូ" active={tab==="upload"} onClick={()=>setTab("upload")}/>
      <NavButton icon={<MessageCircle/>} label="សារ" active={tab==="chat"} onClick={()=>setTab("chat")}/>
      <NavButton icon={<Radio/>} label="ផ្សាយផ្ទាល់" active={tab==="live"} onClick={()=>setTab("live")}/>
      <NavButton icon={<UserRound/>} label="ប្រវត្តិរូប" active={tab==="profile"} onClick={()=>setTab("profile")}/>
      {profile?.role==="admin"&&<NavButton icon={<Shield/>} label="គ្រប់គ្រង" active={tab==="admin"} onClick={()=>setTab("admin")}/>}
      <div className="sideFoot">© {new Date().getFullYear()} KhmerVibe</div>
    </aside>
    <main className="mainContent">
      {notice&&<div className="notice">{notice}<button onClick={()=>setNotice("")}><X size={16}/></button></div>}
      {error&&<div className="errorBanner">{error}<button onClick={()=>setError("")}><X size={16}/></button></div>}
      {tab==="feed"&&<><div className="sectionHead"><div><h1>វីដេអូសម្រាប់អ្នក</h1><p className="muted">ស្វែងរករឿងរ៉ាវ និងចែករំលែកពេលវេលាល្អៗ</p></div><button className="primary" onClick={()=>setTab("upload")}><Plus size={18}/> បង្ហោះវីដេអូ</button></div>
        {visiblePosts.length===0?<div className="empty"><div className="emptyIcon">▶</div><h3>មិនទាន់មានវីដេអូ</h3><p className="muted">ក្លាយជាអ្នកដំបូងដែលចែករំលែកវីដេអូ!</p><button className="primary" onClick={()=>setTab("upload")}>បង្ហោះវីដេអូ</button></div>:
        <div className="videoGrid">{visiblePosts.map(p=><article className="videoCard" key={p.id}><div className="videoFrame"><video src={p.videoUrl} controls playsInline preload="metadata"/></div><div className="videoInfo"><div className="creator"><div className="avatar">{p.ownerName?.slice(0,1)||"K"}</div><div className="creatorText"><b>{p.ownerName}</b><span>@{p.ownerUsername}</span></div>{p.ownerId!==user.uid&&<button className="followBtn" onClick={()=>toggleFollow(p.ownerId)}>{following.includes(p.ownerId)?"កំពុងតាម":"តាមដាន"}</button>}</div><p className="caption">{p.caption||"គ្មានចំណងជើង"}</p><div className="actions"><button className={liked.includes(p.id)?"actionBtn liked":"actionBtn"} onClick={()=>toggleLike(p)}><Heart size={19} fill={liked.includes(p.id)?"currentColor":"none"}/>{kh(p.likesCount)}</button><button className="actionBtn" onClick={()=>setActivePost(p.id)}><MessageCircle size={19}/>{kh(p.commentsCount)}</button><button className="actionBtn" onClick={()=>{navigator.clipboard?.writeText(p.videoUrl);setNotice("បានចម្លងតំណវីដេអូ");}}>ចែករំលែក ↗</button></div></div></article>)}</div>}</>}
      {tab==="upload"&&<section className="panel uploadPanel"><h1>បង្ហោះវីដេអូថ្មី</h1><p className="muted">ទំហំអតិបរមាសម្រាប់គំរូនេះ ២០០ MB។</p><form onSubmit={uploadVideo} className="stack"><label className="fileDrop"><input type="file" accept="video/*" required onChange={e=>setFile(e.target.files?.[0]||null)}/><span className="uploadIcon"><Plus size={26}/></span><b>{file?file.name:"ចុចដើម្បីជ្រើសរើសវីដេអូ"}</b><span className="muted">MP4, WebM និងទម្រង់វីដេអូដែលកម្មវិធីរុករកគាំទ្រ</span></label><label>ចំណងជើង និងការពិពណ៌នា<textarea value={caption} onChange={e=>setCaption(e.target.value)} maxLength={300} rows={4} placeholder="ប្រាប់អ្នកមើលថាវីដេអូនេះនិយាយអំពីអ្វី..."/></label>{uploading&&<div className="progressWrap"><div className="progressBar" style={{width:progress+"%"}}/><span>កំពុងបង្ហោះ {progress}%</span></div>}<button className="primary" disabled={uploading||!file}>{uploading?"កំពុងដំណើរការ...":"បង្ហោះឥឡូវនេះ"}</button></form></section>}
      {tab==="chat"&&<section className="panel chatPanel"><h1>សារឯកជន</h1><p className="muted">បញ្ចូល UID របស់អ្នកប្រើដែលអ្នកចង់ផ្ញើសារ។ ការស្វែងរកអ្នកប្រើនឹងបន្ថែមនៅពេលក្រោយ។</p><label>UID អ្នកទទួល<input value={chatTarget} onChange={e=>setChatTarget(e.target.value.trim())} placeholder="បញ្ចូល UID អ្នកប្រើ" /></label>{chatTarget&&chatTarget===user.uid&&<p className="error">អ្នកមិនអាចផ្ញើសារទៅខ្លួនឯងបានទេ។</p>}<div className="messages">{messages.map(m=><div key={m.id} className={m.senderId===user.uid?"message own":"message"}><b>{m.senderName||"អ្នកប្រើ"}</b><p>{m.text}</p></div>)}</div><form className="sendForm" onSubmit={sendMessage}><input value={chatText} onChange={e=>setChatText(e.target.value)} placeholder="សរសេរសារ..." maxLength={1000}/><button className="primary" disabled={!chatTarget||chatTarget===user.uid||!chatText.trim()}><Send size={18}/></button></form></section>}
      {tab==="live"&&<section className="panel"><div className="liveIcon"><Radio size={28}/></div><h1>ផ្សាយផ្ទាល់</h1><p>មុខងារ Live ត្រូវការសេវា WebRTC/LiveKit និង Token Server ដែលមានសុវត្ថិភាព។ កុំដាក់ LiveKit API Secret នៅក្នុង Frontend។</p><ol className="steps"><li>បង្កើតគម្រោង LiveKit Cloud ឬម៉ាស៊ីនមេ LiveKit របស់អ្នក។</li><li>បង្កើត Backend HTTPS endpoint ដើម្បីផ្ទៀងផ្ទាត់អ្នកប្រើ និងចេញ access token។</li><li>ភ្ជាប់ SDK របស់ LiveKit ហើយបង្ហាញវីដេអូ/សំឡេងពេលចូលបន្ទប់។</li></ol><p className="muted">ផ្ទាំងនេះជាចំណុចចាប់ផ្ដើម មិនទាន់ជាការផ្សាយផ្ទាល់ដែលអាចប្រើបានទេ។</p></section>}
      {tab==="profile"&&<section className="panel profilePanel"><div className="profileHero"><div className="profileAvatar">{profile?.displayName?.slice(0,1)||"K"}</div><div><h1>{profile?.displayName}</h1><p className="muted">@{profile?.username}</p><p>{profile?.bio||"សូមស្វាគមន៍មកកាន់ KhmerVibe!"}</p></div></div><div className="statGrid"><div><b>{posts.filter(p=>p.ownerId===user.uid).length}</b><span>វីដេអូ</span></div><div><b>{following.length}</b><span>កំពុងតាមដាន</span></div></div><h2>វីដេអូរបស់ខ្ញុំ</h2><div className="videoGrid">{posts.filter(p=>p.ownerId===user.uid).map(p=><article className="videoCard" key={p.id}><div className="videoFrame"><video src={p.videoUrl} controls playsInline/></div><div className="videoInfo"><p>{p.caption}</p><button className="danger" onClick={async()=>{if(confirm("តើអ្នកប្រាកដថាចង់លុបវីដេអូនេះឬ?")) await deleteDoc(doc(db,"videos",p.id));}}>លុបវីដេអូ</button></div></article>)}</div></section>}
      {tab==="admin"&&<section className="panel"><h1><Shield/> ផ្ទាំងគ្រប់គ្រង Admin</h1>{profile?.role!=="admin"?<p className="error">គណនីនេះមិនមានសិទ្ធិ Admin ទេ។</p>:<><p>វីដេអូសរុប៖ {posts.length}</p><p>អ្នកប្រើត្រូវកំណត់ role=admin ដោយម្ចាស់គម្រោងតាម Firebase Console ដែលមានការការពារ។</p><div className="adminList">{posts.map(p=><div className="adminRow" key={p.id}><span>{p.caption||"គ្មានចំណងជើង"}</span><small>{p.ownerName}</small><button className="danger" onClick={async()=>{if(confirm("លុបវីដេអូនេះ?")) await deleteDoc(doc(db,"videos",p.id));}}>លុប</button></div>)}</div></>}</section>}
    </main>
    {activePost&&<div className="modalBackdrop" onClick={()=>setActivePost("")}><section className="commentModal" onClick={e=>e.stopPropagation()}><header><h2>មតិយោបល់</h2><button className="iconButton" onClick={()=>setActivePost("")}><X/></button></header><div className="commentList">{comments.map(c=><div className="comment" key={c.id}><div className="avatar">{c.username?.slice(0,1)||"U"}</div><div><b>@{c.username}</b><p>{c.text}</p></div></div>)}</div><form className="sendForm" onSubmit={addComment}><input value={commentText} onChange={e=>setCommentText(e.target.value)} maxLength={500} placeholder="សរសេរមតិយោបល់..."/><button className="primary" disabled={!commentText.trim()}><Send size={18}/></button></form></section></div>}
    <nav className="mobileNav"><NavButton icon={<House/>} label="ទំព័រដើម" active={tab==="feed"} onClick={()=>setTab("feed")}/><NavButton icon={<Plus/>} label="បង្ហោះ" active={tab==="upload"} onClick={()=>setTab("upload")}/><NavButton icon={<MessageCircle/>} label="សារ" active={tab==="chat"} onClick={()=>setTab("chat")}/><NavButton icon={<Radio/>} label="Live" active={tab==="live"} onClick={()=>setTab("live")}/><NavButton icon={<UserRound/>} label="គណនី" active={tab==="profile"} onClick={()=>setTab("profile")}/></nav>
  </div>;
}
function NavButton({icon,label,active,onClick}:{icon:React.ReactNode;label:string;active:boolean;onClick:()=>void}) {
  return <button className={active?"navButton active":"navButton"} onClick={onClick}>{icon}<span>{label}</span></button>;
}
function friendlyError(code?:string) {
  const map:Record<string,string>={"auth/invalid-credential":"អ៊ីមែល ឬពាក្យសម្ងាត់មិនត្រឹមត្រូវ។","auth/email-already-in-use":"អ៊ីមែលនេះមានគណនីរួចហើយ។","auth/weak-password":"ពាក្យសម្ងាត់ត្រូវមានយ៉ាងតិច ៦ តួ។","auth/invalid-email":"អ៊ីមែលមិនត្រឹមត្រូវ។","auth/too-many-requests":"មានការព្យាយាមច្រើនពេក។ សូមសាកល្បងម្ដងទៀតពេលក្រោយ។"};
  return code?map[code]:"";
}
